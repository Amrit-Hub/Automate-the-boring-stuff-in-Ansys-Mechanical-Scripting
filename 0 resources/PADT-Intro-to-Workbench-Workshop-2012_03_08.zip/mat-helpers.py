﻿def modifyMats(propa,propb,val):
	sys = GetSystem(Name=curSysName)
	ed  = sys.GetContainer(ComponentName="Engineering Data")
	mat = ed.GetMaterial(Name=curMatName)
	propc = mat.GetProperty(Name=propa)
	propc.SetData(
    		Variables=[propb],
    		Values=[val])

