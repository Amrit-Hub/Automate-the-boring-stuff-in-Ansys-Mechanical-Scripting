﻿# setDens("SYS 1", "Structural Steel", "1234.34 [kg m^-3]")
def setDens(sysName,matName,densval):
	sys = GetSystem(Name=sysName)
	ed  = sys.GetContainer(ComponentName="Engineering Data")
	mat = ed.GetMaterial(Name=matName)
	densProp = mat.GetProperty(Name="Density")
	densProp.SetData(
    		Variables=["Density"],
    		Values=[densval])

