import os

def writeParams():
	outFile = open("c:/temp/foo.out","w")
	for param in Parameters.GetAllParameters():
		outFile.write(param.Name + ", " + param.DisplayText + ", " +
param.Value.ToString() + "\n")
	outFile.flush()
	outFile.close()

writeParams()

